<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile CDSHooksResponse
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:CDSHooksResponse/f:cards</sch:title>
    <sch:rule context="f:CDSHooksResponse/f:cards">
      <sch:assert test="count(f:uuid) &gt;= 1">uuid: minimum cardinality of 'uuid' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:CDSHooksResponse/f:cards/f:source</sch:title>
    <sch:rule context="f:CDSHooksResponse/f:cards/f:source">
      <sch:assert test="count(f:topic) &gt;= 1">topic: minimum cardinality of 'topic' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:CDSHooksResponse/f:cards/f:suggestions/f:actions</sch:title>
    <sch:rule context="f:CDSHooksResponse/f:cards/f:suggestions/f:actions">
      <sch:assert test="count(f:description) &gt;= 1">description: minimum cardinality of 'description' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:CDSHooksResponse/f:cards/f:links</sch:title>
    <sch:rule context="f:CDSHooksResponse/f:cards/f:links">
      <sch:assert test="count(f:type) &gt;= 1">type: minimum cardinality of 'type' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:CDSHooksResponse/f:systemActions</sch:title>
    <sch:rule context="f:CDSHooksResponse/f:systemActions">
      <sch:assert test="count(f:extension) &lt;= 1">extension: maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:type) &gt;= 1">type: minimum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:type) &lt;= 1">type: maximum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:description) &lt;= 1">description: maximum cardinality of 'description' is 1</sch:assert>
      <sch:assert test="count(f:resource) &lt;= 1">resource: maximum cardinality of 'resource' is 1</sch:assert>
      <sch:assert test="count(f:resourceId) &lt;= 1">resourceId: maximum cardinality of 'resourceId' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
